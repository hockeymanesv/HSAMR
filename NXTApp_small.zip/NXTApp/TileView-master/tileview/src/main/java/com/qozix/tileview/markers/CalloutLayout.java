package com.qozix.tileview.markers;

import android.content.Context;

/**
 * @deprecated In the next major version, instances of this class will be replaced
 * by instances of MarkerLayout
 */
public class CalloutLayout extends MarkerLayout {

  public CalloutLayout( Context context ) {
    super( context );
  }

}
