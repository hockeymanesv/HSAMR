package com.example.paulforster.nxtapp;

/**
 * obsolete
 * @author paulforster
 */

public interface StatusChangeListener {
    public void onChange();
}
